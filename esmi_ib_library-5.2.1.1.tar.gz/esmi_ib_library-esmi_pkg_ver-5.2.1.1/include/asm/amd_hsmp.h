/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */

#ifndef _UAPI_ASM_X86_AMD_HSMP_H_
#define _UAPI_ASM_X86_AMD_HSMP_H_

#include <linux/types.h>

#pragma pack(4)

#define HSMP_MAX_MSG_LEN 8

/*
 * HSMP Messages supported
 */
enum hsmp_message_ids {
	HSMP_TEST = 1,			/* 01h Increments input value by 1 */
	HSMP_GET_SMU_VER,		/* 02h SMU FW version */
	HSMP_GET_PROTO_VER,		/* 03h HSMP interface version */
	HSMP_GET_SOCKET_POWER,		/* 04h average package power consumption */
	HSMP_SET_SOCKET_POWER_LIMIT,	/* 05h Set the socket power limit */
	HSMP_GET_SOCKET_POWER_LIMIT,	/* 06h Get current socket power limit */
	HSMP_GET_SOCKET_POWER_LIMIT_MAX,/* 07h Get maximum socket power value */
	HSMP_SET_BOOST_LIMIT,		/* 08h Set a core maximum frequency limit */
	HSMP_SET_BOOST_LIMIT_SOCKET,	/* 09h Set socket maximum frequency level */
	HSMP_GET_BOOST_LIMIT,		/* 0Ah Get current frequency limit */
	HSMP_GET_PROC_HOT,		/* 0Bh Get PROCHOT status */
	HSMP_SET_XGMI_LINK_WIDTH,	/* 0Ch Set max and min width of xGMI Link */
	HSMP_SET_DF_PSTATE,		/* 0Dh Alter APEnable/Disable messages behavior */
	HSMP_SET_AUTO_DF_PSTATE,	/* 0Eh Enable DF P-State Performance Boost algorithm */
	HSMP_GET_FCLK_MCLK,		/* 0Fh Get FCLK and MEMCLK for current socket */
	HSMP_GET_CCLK_THROTTLE_LIMIT,	/* 10h Get CCLK frequency limit in socket */
	HSMP_GET_C0_PERCENT,		/* 11h Get average C0 residency in socket */
	HSMP_SET_NBIO_DPM_LEVEL,	/* 12h Set max/min LCLK DPM Level for a given NBIO */
	HSMP_GET_NBIO_DPM_LEVEL,	/* 13h Get LCLK DPM level min and max for a given NBIO */
	HSMP_GET_DDR_BANDWIDTH,		/* 14h Get theoretical maximum and current DDR Bandwidth */
	HSMP_GET_TEMP_MONITOR,		/* 15h Get socket temperature */
	HSMP_GET_DIMM_TEMP_RANGE,	/* 16h Get per-DIMM temperature range and refresh rate */
	HSMP_GET_DIMM_POWER,		/* 17h Get per-DIMM power consumption */
	HSMP_GET_DIMM_THERMAL,		/* 18h Get per-DIMM thermal sensors */
	HSMP_GET_SOCKET_FREQ_LIMIT,	/* 19h Get current active frequency per socket */
	HSMP_GET_CCLK_CORE_LIMIT,	/* 1Ah Get CCLK frequency limit per core */
	HSMP_GET_RAILS_SVI,		/* 1Bh Get SVI-based Telemetry for all rails */
	HSMP_GET_SOCKET_FMAX_FMIN,	/* 1Ch Get Fmax and Fmin per socket */
	HSMP_GET_IOLINK_BANDWITH,	/* 1Dh Get current bandwidth on IO Link */
	HSMP_GET_XGMI_BANDWITH,		/* 1Eh Get current bandwidth on xGMI Link */
	HSMP_SET_GMI3_WIDTH,		/* 1Fh Set max and min GMI3 Link width */
	HSMP_SET_PCI_RATE,		/* 20h Control link rate on PCIe devices */
	HSMP_SET_POWER_MODE,		/* 21h Select power efficiency profile policy */
	HSMP_SET_PSTATE_MAX_MIN,	/* 22h Set the max and min DF P-State  */
	HSMP_GET_METRIC_TABLE_VER,	/* 23h Get metrics table version */
	HSMP_GET_METRIC_TABLE,		/* 24h Get metrics table */
	HSMP_GET_METRIC_TABLE_DRAM_ADDR,/* 25h Get metrics table dram address */
	HSMP_SET_XGMI_PSTATE_RANGE,	/* 26h Set xGMI P-state range */
	HSMP_CPU_RAIL_ISO_FREQ_POLICY,	/* 27h Get/Set Cpu Iso frequency policy */
	HSMP_DFC_ENABLE_CTRL,		/* 28h Enable/Disable DF C-state */
	HSMP_PC6_ENABLE,		/* 29h Get/Set PC6 Enable/Disable Status */
	HSMP_CC6_ENABLE,		/* 2Ah Get/Set CC6 Enable/Disable Status */
	HSMP_GET_RAPL_UNITS = 0x30,	/* 30h Get scaling factor for energy */
	HSMP_GET_RAPL_CORE_COUNTER,	/* 31h Get core energy counter value */
	HSMP_GET_RAPL_PACKAGE_COUNTER,	/* 32h Get package energy counter value */
	HSMP_DIMM_SB_RD,		/* 33h Get data from a specified device on the DIMM.*/
	HSMP_READ_CCD_POWER,		/* 34h Get the average power consumed by CCD */
	HSMP_READ_TDELTA,		/* 35h Get thermal solution behaviour */
	HSMP_GET_SVI3_VR_CTRL_TEMP,	/* 36h Get temperature of SVI3 VR controller rails */
	HSMP_GET_ENABLED_HSMP_CMDS,	/* 37h Get/Set supported HSMP commands */
	HSMP_SET_GET_FLOOR_LIMIT,       /* 38h Get/Set supported Floor limit commands */
	HSMP_DIMM_SB_WR,                /* 39h Set data to a specified device on the DIMM */
	HSMP_SDPS_LIMIT,                /* 3Ah Get/Set SDPS limit */
	HSMP_MSG_ID_MAX,
};

struct hsmp_message {
	__u32	msg_id;			/* Message ID */
	__u16	num_args;		/* Number of input argument words in message */
	__u16	response_sz;		/* Number of expected output/response words */
	__u32	args[HSMP_MAX_MSG_LEN];	/* argument/response buffer */
	__u16	sock_ind;		/* socket number */
};

enum hsmp_msg_type {
	HSMP_RSVD	= -1,
	HSMP_SET	= 0,
	HSMP_GET	= 1,
	HSMP_SET_GET 	= 2,
};

enum hsmp_proto_versions {
	HSMP_PROTO_VER2	= 2,
	HSMP_PROTO_VER3,
	HSMP_PROTO_VER4,
	HSMP_PROTO_VER5,
	HSMP_PROTO_VER6,
	HSMP_PROTO_VER7
};

struct hsmp_msg_desc {
	int num_args;
	int response_sz;
	enum hsmp_msg_type type;
};

/*
 * User may use these comments as reference, please find the
 * supported list of messages and message definition in the
 * HSMP chapter of respective family/model PPR.
 *
 * Not supported messages would return -ENOMSG.
 */
static const struct hsmp_msg_desc hsmp_msg_desc_table[] = {
	/* RESERVED */
	{0, 0, HSMP_RSVD},

	/*
	 * HSMP_TEST, num_args = 1, response_sz = 1
	 * input:  args[0] = xx
	 * output: args[0] = xx + 1
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_SMU_VER, num_args = 0, response_sz = 1
	 * output: args[0] = smu fw ver
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_PROTO_VER, num_args = 0, response_sz = 1
	 * output: args[0] = proto version
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_SOCKET_POWER, num_args = 0, response_sz = 1
	 * output: args[0] = socket power in mWatts
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_SET_SOCKET_POWER_LIMIT, num_args = 1, response_sz = 0
	 * input: args[0] = power limit value in mWatts
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_GET_SOCKET_POWER_LIMIT, num_args = 0, response_sz = 1
	 * output: args[0] = socket power limit value in mWatts
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_SOCKET_POWER_LIMIT_MAX, num_args = 0, response_sz = 1
	 * output: args[0] = maximuam socket power limit in mWatts
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_SET_BOOST_LIMIT, num_args = 1, response_sz = 0
	 * input: args[0] = apic id[31:16] + boost limit value in MHz[15:0]
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_SET_BOOST_LIMIT_SOCKET, num_args = 1, response_sz = 0
	 * input: args[0] = boost limit value in MHz
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_GET_BOOST_LIMIT, num_args = 1, response_sz = 1
	 * input: args[0] = apic id
	 * output: args[0] = boost limit value in MHz
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_PROC_HOT, num_args = 0, response_sz = 1
	 * output: args[0] = proc hot status
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_SET_XGMI_LINK_WIDTH, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get XGMI Link width[31] + min link width[15:8] + max link width[7:0]
	 * output: args[0] = current min link width[15:8] + current max link width[7:0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_SET_DF_PSTATE, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get df pstate[31] + df pstate[7:0]
	* output: args[0] = APB Enabled/Disabled[8]+current df pstate[7:0]
	 */
	{1, 1, HSMP_SET_GET},

	/* HSMP_SET_AUTO_DF_PSTATE, num_args = 0, response_sz = 0 */
	{0, 0, HSMP_SET},

	/*
	 * HSMP_GET_FCLK_MCLK, num_args = 0, response_sz = 2
	 * output: args[0] = fclk in MHz, args[1] = mclk in MHz
	 */
	{0, 2, HSMP_GET},

	/*
	 * HSMP_GET_CCLK_THROTTLE_LIMIT, num_args = 0, response_sz = 1
	 * output: args[0] = core clock in MHz
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_C0_PERCENT, num_args = 0, response_sz = 1
	 * output: args[0] = average c0 residency
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_SET_NBIO_DPM_LEVEL, num_args = 1, response_sz = 0
	 * input: args[0] = nbioid[23:16] + max dpm level[15:8] + min dpm level[7:0]
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_GET_NBIO_DPM_LEVEL, num_args = 1, response_sz = 1
	 * input: args[0] = nbioid[23:16]
	 * output: args[0] = max dpm level[15:8] + min dpm level[7:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_DDR_BANDWIDTH, num_args = 0, response_sz = 1
	 * output: args[0] = max bw in Gbps[31:20] + utilised bw in Gbps[19:8] +
	 * bw in percentage[7:0]
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_TEMP_MONITOR, num_args = 0, response_sz = 1
	 * output: args[0] = temperature in degree celsius. [15:8] integer part +
	 * [7:5] fractional part
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_DIMM_TEMP_RANGE, num_args = 1, response_sz = 1
	 * input: args[0] = DIMM address[7:0]
	 * output: args[0] = refresh rate[3] + temperature range[2:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_DIMM_POWER, num_args = 1, response_sz = 1
	 * input: args[0] = DIMM address[7:0]
	 * output: args[0] = DIMM power in mW[31:17] + update rate in ms[16:8] +
	 * DIMM address[7:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_DIMM_THERMAL, num_args = 1, response_sz = 1
	 * input: args[0] = DIMM address[7:0]
	 * output: args[0] = temperature in degree celcius[31:21] + update rate in ms[16:8] +
	 * DIMM address[7:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_SOCKET_FREQ_LIMIT, num_args = 0, response_sz = 1
	 * output: args[0] = frequency in MHz[31:16] + frequency source[15:0]
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_CCLK_CORE_LIMIT, num_args = 1, response_sz = 1
	 * input: args[0] = apic id of the core[31:0]
	 * output: args[0] = frequency in MHz[31:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_RAILS_SVI, num_args = 0, response_sz = 1
	 * output: args[0] = power in mW[31:0]
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_SOCKET_FMAX_FMIN, num_args = 0, response_sz = 1
	 * output: args[0] = fmax in MHz[31:16] + fmin in MHz[15:0]
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_IOLINK_BANDWITH, num_args = 1, response_sz = 1
	 * input: args[0] = link id[15:8] + bw type[2:0]
	 * output: args[0] = io bandwidth in Mbps[31:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_XGMI_BANDWITH, num_args = 1, response_sz = 1
	 * input: args[0] = link id[15:8] + bw type[2:0]
	 * output: args[0] = xgmi bandwidth in Mbps[31:0]
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_SET_GMI3_WIDTH, num_args = 1, response_sz = 0
	 * input: args[0] = min link width[15:8] + max link width[7:0]
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_SET_PCI_RATE, num_args = 1, response_sz = 1
	 * input: args[0] = link rate control value[7:0]
	 * output: args[0] = previous link rate control value
	 */
	{1, 1, HSMP_SET},

	/*
	 * HSMP_SET_POWER_MODE, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get power mode[31] + power efficiency mode[2:0]
	 * output: args[0] = current power efficiency mode[2:0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_SET_PSTATE_MAX_MIN, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get power mode[31] + min df pstate[15:8] + max df pstate[7:0]
	* output: args[0] = min df pstate[15:8] + max df pstate[7:0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_GET_METRIC_TABLE_VER, num_args = 0, response_sz = 1
	 * output: args[0] = metrics table version
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_METRIC_TABLE, num_args = 0, response_sz = 0
	 */
	{0, 0, HSMP_GET},

	/*
	 * HSMP_GET_METRIC_TABLE_DRAM_ADDR, num_args = 0, response_sz = 2
	 * output: args[0] = lower 32 bits of the address
	 * output: args[1] = upper 32 bits of the address
	 */
	{0, 2, HSMP_GET},

	/*
	 * HSMP_SET_XGMI_PSTATE_RANGE, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get XGMI pstate range[31] + min xGMI p-state[15:8] + max xGMI state[7:0]
	* output: args[0] = min xGMI p-state[15:8] + max xGMI state[7:0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_CPU_RAIL_ISO_FREQ_POLICY, num_args = 1, response_sz = 1
	 * input: args[0] = set/get policy[31] +
	 * disable/enable independent control[0]
	 * output: args[0] = current policy[0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_DFC_ENABLE_CTRL, num_args = 1, response_sz = 1
	 * input: args[0] = set/get policy[31] + enable/disable DFC[0]
	 * output: args[0] = current policy[0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_PC6_ENABLE, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get PC6 control[31] + disable/enable PC6[0]
	 * output: args[0] = current PC6 control status[0]
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_CC6_ENABLE, num_args = 1, response_sz = 0/1
	 * input: args[0] = set/get CC6 control[31] + disable/enable CC6[0]
	 * output: args[0] = current CC6 control status[0]
	 */
	{1, 1, HSMP_SET_GET},

	/* RESERVED(0x2B-0x2F) */
	{0, 0, HSMP_RSVD},
	{0, 0, HSMP_RSVD},
	{0, 0, HSMP_RSVD},
	{0, 0, HSMP_RSVD},
	{0, 0, HSMP_RSVD},

	/*
	 * HSMP_GET_RAPL_UNITS, response_sz = 1
	 * output: args[0] = tu value[19:16] + esu value[12:8]
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_RAPL_CORE_COUNTER, num_args = 1, response_sz = 1
	 * input: args[0] = Apic id[15:0]
	 * output: args[0] = lower 32 bits of energy
	 * output: args[1] = upper 32 bits of energy
	 */
	{1, 2, HSMP_GET},

	/*
	 * HSMP_GET_RAPL_PACKAGE_COUNTER, num_args = 0, response_sz = 1
	 * output: args[0] = lower 32 bits of energy
	 * output: args[1] = upper 32 bits of energy
	 */
	{0, 2, HSMP_GET},

	/*
	 * HSMP_DIMM_SB_RD, num_args = 1, response_sz = 1
	 * input: args[0] =
	 * 		     [07:00] DIMM address
	 * 		     [11:08] LID of device
	 * 		     [22:12] Register offset in given reg space
	 * 		     [23]    Register space
	 * output: args[0] = [03:00] Read data byte
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_READ_CCD_POWER, num_args = 1, response_sz = 1
	 * input: args[0] = [15:00] ApicId of core
	 * output: args[0] = [31:00] CCD power(mWatts)
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_READ_TDELTA, num_args = 0, response_sz = 1
	 * input: None
	 * output: args[0] = [31:00] Thermal Behaviour
	 */
	{0, 1, HSMP_GET},

	/*
	 * HSMP_GET_SVI3_VR_CTRL_TEMP, num_args = 1, response_sz = 1
	 * input: args[0] =
	 * 		     [00] Read SVI3 temperature data
	 * 		     [03:01] SVI3 rail index
	 * output: args[0] =
	 * 		     [30:28] SVI3 rail index
	 * 		     [27:00] SVI3 rail temperature(degree C)
	 */
	{1, 1, HSMP_GET},

	/*
	 * HSMP_GET_ENABLED_HSMP_CMDS, num_args = 1, response_sz = 3
	 * input: args[0] = [00] HSMP command mask
	 * output: args[0], args[1], args[2] = status of HSMP command
	 */
	{1, 3, HSMP_GET},

	/*
	 * HSMP_SET_GET_FLOOR_LIMIT, num_args = 1, response_sz = 1
	 * input: args[0] =
	 *	Set or Get[31:30]
	 *		Set the Floor frequency per core = 00
	 *		Set the Floor frequency for all cores = 01
	 *		Get the Floor frequency of a core = 10
	 *		Get the Effective Floor frequency per core = 11
	 *	Reserved[29:28]
	 *	Apic id / Reserved[27:16]
	 *		args[27:16] is reserved if arg[31:30] is 01
	 *	Floor frequency limit / Reserved[15:0]
	 *		if args[31] = 0, Floor frequency limit, else reserved
	 *
	 * output: args[0] =
	 *	Effective Floor frequency limit(MHz) / None / Floor frequency limit[15:0]
	 *		Effective Floor frequency if input args[31:30] = 11
	 *		None if input args[31] = 0
	 *		Floor frequency limit (MHz)[15:0] if args[31:30] = 10
	 */
	{1, 1, HSMP_SET_GET},

	/*
	 * HSMP_DIMM_SB_WR, num_args = 1, response_sz = 0
	 * input: args[0] =
	 *	Write Data[31:24]
	 *	Register space[23]
	 *	Register offset in given reg space[22:12]
	 *	LID of device[11:8]
	 *	DIMM address[7:0]
	 * output: None
	 */
	{1, 0, HSMP_SET},

	/*
	 * HSMP_SDPS_LIMIT, num_args = 1, response_sz = 1
	 * input: args[0] = Set/Get[31] + SDPS Limit[30:0]
	 * output: args[0] = SDPS Limit[30:0]
	 */
	{1, 1, HSMP_SET_GET},
};

/* Metrics table (supported only with proto version 6) */
struct hsmp_metric_table {
	__u32 accumulation_counter;

	/* TEMPERATURE */
	__u32 max_socket_temperature;
	__u32 max_vr_temperature;
	__u32 max_hbm_temperature;
	__u64 max_socket_temperature_acc;
	__u64 max_vr_temperature_acc;
	__u64 max_hbm_temperature_acc;

	/* POWER */
	__u32 socket_power_limit;
	__u32 max_socket_power_limit;
	__u32 socket_power;

	/* ENERGY */
	__u64 timestamp;
	__u64 socket_energy_acc;
	__u64 ccd_energy_acc;
	__u64 xcd_energy_acc;
	__u64 aid_energy_acc;
	__u64 hbm_energy_acc;

	/* FREQUENCY */
	__u32 cclk_frequency_limit;
	__u32 gfxclk_frequency_limit;
	__u32 fclk_frequency;
	__u32 uclk_frequency;
	__u32 socclk_frequency[4];
	__u32 vclk_frequency[4];
	__u32 dclk_frequency[4];
	__u32 lclk_frequency[4];
	__u64 gfxclk_frequency_acc[8];
	__u64 cclk_frequency_acc[96];

	/* FREQUENCY RANGE */
	__u32 max_cclk_frequency;
	__u32 min_cclk_frequency;
	__u32 max_gfxclk_frequency;
	__u32 min_gfxclk_frequency;
	__u32 fclk_frequency_table[4];
	__u32 uclk_frequency_table[4];
	__u32 socclk_frequency_table[4];
	__u32 vclk_frequency_table[4];
	__u32 dclk_frequency_table[4];
	__u32 lclk_frequency_table[4];
	__u32 max_lclk_dpm_range;
	__u32 min_lclk_dpm_range;

	/* XGMI */
	__u32 xgmi_width;
	__u32 xgmi_bitrate;
	__u64 xgmi_read_bandwidth_acc[8];
	__u64 xgmi_write_bandwidth_acc[8];

	/* ACTIVITY */
	__u32 socket_c0_residency;
	__u32 socket_gfx_busy;
	__u32 dram_bandwidth_utilization;
	__u64 socket_c0_residency_acc;
	__u64 socket_gfx_busy_acc;
	__u64 dram_bandwidth_acc;
	__u32 max_dram_bandwidth;
	__u64 dram_bandwidth_utilization_acc;
	__u64 pcie_bandwidth_acc[4];

	/* THROTTLERS */
	__u32 prochot_residency_acc;
	__u32 ppt_residency_acc;
	__u32 socket_thm_residency_acc;
	__u32 vr_thm_residency_acc;
	__u32 hbm_thm_residency_acc;
	__u32 spare;

	/* New items at the end to maintain driver compatibility */
	__u32 gfxclk_frequency[8];
};

#define F1A_M50_M5F_MAX_CORES_PER_CCD_32 32
#define F1A_M50_M5F_MAX_FREQ_TABLE_SIZE  4
#define F1A_M50_M5F_MAX_XGMI             8
#define F1A_M50_M5F_MAX_PCIE             8
#define F1A_M50_M5F_MAX_CCD              8

/* Metrics table (supported only with proto version 7) */
struct hsmp_metric_table_f1a_m50_5f_iod {
	__u32 num_active_ccds;
	__u32 accumulation_counter;

	/* TEMPERATURE */
	__u64 max_socket_temperature_acc;

	/* POWER */
	__u32 socket_power_limit;
	__u32 max_socket_power_limit;
	__u64 socket_power_acc;
	__u64 core_power_acc;
	__u64 uncore_power_acc;

	/* ENERGY */
	__u64 timestamp;
	__u64 socket_energy_acc;
	__u64 core_energy_acc;
	__u64 uncore_energy_acc;

	/* FREQUENCY */
	__u64 fclk_frequency_acc;
	__u64 uclk_frequency_acc;
	__u64 ddr_rate_acc;
	__u64 lclk_frequency_acc[F1A_M50_M5F_MAX_FREQ_TABLE_SIZE];

	/* FREQUENCY RANGE */
	__u32 fclk_frequency_table[F1A_M50_M5F_MAX_FREQ_TABLE_SIZE];
	__u32 uclk_frequency_table[F1A_M50_M5F_MAX_FREQ_TABLE_SIZE];
	__u32 ddr_rate_table[F1A_M50_M5F_MAX_FREQ_TABLE_SIZE];
	__u32 max_df_pstate_range;
	__u32 min_df_pstate_range;
	__u32 lclk_frequency_table[F1A_M50_M5F_MAX_FREQ_TABLE_SIZE];
	__u32 max_lclk_dpm_range;
	__u32 min_lclk_dpm_range;

	/* XGMI */
	__u64 xgmi_bit_rate[F1A_M50_M5F_MAX_XGMI];
	__u64 xgmi_read_bandwidth[F1A_M50_M5F_MAX_XGMI];
	__u64 xgmi_write_bandwidth[F1A_M50_M5F_MAX_XGMI];

	/* ACTIVITY */
	__u64 socket_c0_residency_acc;
	__u64 socket_df_cstate_residency_acc;
	__u64 dram_read_bandwidth_acc;
	__u64 dram_write_bandwidth_acc;
	__u32 max_dram_bandwidth;
	__u64 pcie_bandwidth_acc[F1A_M50_M5F_MAX_PCIE];

	/* THROTTLERS */
	__u32 prochot_residency_acc;
	__u32 ppt_residency_acc;
	__u32 thm_residency_acc;
	__u32 vrhot_residency_acc;
	__u32 cpu_tdc_residency_acc;
	__u32 soc_tdc_residency_acc;
	__u32 io_mem_tdc_residency_acc;
	__u32 fit_residency_acc;
};

struct hsmp_metric_table_f1a_m50_5f_ccd {
	__u32 core_apicid_of_thread0[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_c0[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_cc1[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_cc6[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_frequency[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_frequency_effective[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
	__u64 core_power[F1A_M50_M5F_MAX_CORES_PER_CCD_32];
};

struct hsmp_metric_table_f1a_m50_5f {
	struct hsmp_metric_table_f1a_m50_5f_iod	 iod;
	struct hsmp_metric_table_f1a_m50_5f_ccd  ccd[F1A_M50_M5F_MAX_CCD];
};

/* Reset to default packing */
#pragma pack()

int hsmp_send_message(struct hsmp_message *msg);

/* Define unique ioctl command for hsmp msgs using generic _IOWR */
#define HSMP_BASE_IOCTL_NR	0xF8
#define HSMP_IOCTL_CMD		_IOWR(HSMP_BASE_IOCTL_NR, 0, struct hsmp_message)

#endif /*_ASM_X86_AMD_HSMP_H_*/
